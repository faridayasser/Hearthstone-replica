package model.cards.spells;

import model.heroes.Hero;

public interface HeroTargetSpell {
	public void performAction(Hero h);
}
