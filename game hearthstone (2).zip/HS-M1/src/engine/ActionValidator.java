package engine;

import exceptions.NotYourTurnException;
import model.heroes.Hero;
import model.cards.minions.*;
import model.cards.*;
import exceptions.*;
public interface ActionValidator {
		public void validateTurn(Hero user) throws NotYourTurnException;
		public void validateAttack(Minion attacker,Minion target) throws CannotAttackException,NotSummonedException, TauntBypassException,InvalidTargetException;
		public void validateAttack(Minion attacker,Hero target) throws CannotAttackException,NotSummonedException, TauntBypassException,InvalidTargetException;
		public void validateManaCost(Card card) throws NotEnoughManaException;
		public void validatePlayingMinion(Minion minion) throws FullFieldException;
		public void validateUsingHeroPower(Hero hero) throws NotEnoughManaException, HeroPowerAlreadyUsedException;

}
