package engine;

import exceptions.CannotAttackException;
import exceptions.FullFieldException;
import exceptions.FullHandException;
import exceptions.HeroPowerAlreadyUsedException;
import exceptions.InvalidTargetException;
import exceptions.NotEnoughManaException;
import exceptions.NotSummonedException;
import exceptions.NotYourTurnException;
import exceptions.TauntBypassException;
import model.cards.Card;
import model.cards.minions.Minion;
import model.heroes.Hero;
import model.heroes.HeroListener;

public class Game  implements ActionValidator, HeroListener{
	private Hero firstHero;
	private Hero secondHero;
	private Hero currentHero;
	private Hero opponent;
	private GameListener listener;
	
	public Game(Hero p1, Hero p2) throws FullHandException, CloneNotSupportedException
	{
		firstHero=p1;
		secondHero=p2;
		
		int coin = (int) (Math.random()*2);
		currentHero= coin==0?firstHero:secondHero;
		opponent= currentHero==firstHero?secondHero:firstHero;
		currentHero.setCurrentManaCrystals(1);
		currentHero.setTotalManaCrystals(1);
		currentHero.setListener(this);
		opponent.setListener(this);
		currentHero.setValidator(this);
		opponent.setValidator(this);
		for(int i=0;i<3;i++) {
			currentHero.drawCard();
		}
		for(int i=0;i<4;i++) {
			opponent.drawCard();
		}
		
	}

	public Hero getCurrentHero() {
		return currentHero;
	}

	public Hero getOpponent() {
		return opponent;
	}

	public void setListener(GameListener listener) {
		this.listener = listener;
	}

	@Override
	public void validateTurn(Hero user) throws NotYourTurnException {
		if(!this.getCurrentHero().equals(user)) {
			throw new NotYourTurnException("This is not your turn");
		}
		
	}

	@Override
	public void validateAttack(Minion attacker, Minion target)
			throws CannotAttackException, NotSummonedException, TauntBypassException, InvalidTargetException {
		if (attacker.isSleeping()==true) {
			throw new CannotAttackException("Minion is sleeping");
		}
		if (attacker.getAttack() == 0){
			throw new CannotAttackException("Minion has no attacking points");
		}
		if(attacker.isAttacked()) {
			throw new CannotAttackException("This minion has already attacked before");
			}
		if (this.getCurrentHero().getField().contains(target)) {
			throw new InvalidTargetException("Target minion is a friendly minion");
		}
		if (!(this.getCurrentHero().getField().contains(attacker))){
			throw new NotSummonedException("Attacker minion is still in hand");
		}
		boolean taunt=false;
		for (int i=0;i<this.getOpponent().getField().size();i++) {
			if (this.getOpponent().getField().get(i).isTaunt()) {
				taunt = true;
			}
		}
		if(taunt && target.isTaunt()==false) {
			throw new TauntBypassException("The opponent has a taunt minion on their field");
		}
		if (!(this.getOpponent().getField().contains(target))) {
			throw new NotSummonedException("Target minion is not on Field");
		}
		
			
	}

	@Override
	public void validateAttack(Minion attacker, Hero target)
			throws CannotAttackException, NotSummonedException, TauntBypassException, InvalidTargetException {
		if (attacker.isSleeping()==true) {
			throw new CannotAttackException("Minion is sleeping");
		}
		if (attacker.getAttack()==0){
			throw new CannotAttackException("Minion has no attacking points");
			}
		if(attacker.isAttacked()) {
			throw new CannotAttackException("This minion has already attacked before");
		}
		if (attacker.getName().equalsIgnoreCase("Icehowl")) {
			throw new InvalidTargetException("Icehowl cannot attack heroes");
		}
		boolean taunt=false;
		for (int i=0;i<this.getOpponent().getField().size();i++) {
			if (this.getOpponent().getField().get(i).isTaunt()) {
				taunt = true;
			}
		}
		if(taunt == true) {
			throw new TauntBypassException("The opponent has a taunt minion on their field");
		}
		if (!(this.getCurrentHero().getField().contains(attacker))){
			throw new NotSummonedException("Attacker minion is still in hand");
			}
		
	}

	@Override
	public void validateManaCost(Card card) throws NotEnoughManaException {
		if(this.getCurrentHero().getTotalManaCrystals()< card.getManaCost()) {
			throw new NotEnoughManaException("You do not have enough manaCrystals to use this card");
		}
		
	}

	@Override
	public void validatePlayingMinion(Minion minion) throws FullFieldException {
		if(this.getCurrentHero().getField().size() ==7) {
			throw new FullFieldException("Your field is full,so you can't play this minion");
		}
		
	}

	@Override
	public void validateUsingHeroPower(Hero hero) throws NotEnoughManaException, HeroPowerAlreadyUsedException {
		if(this.getCurrentHero().isHeroPowerUsed()) {
			throw new HeroPowerAlreadyUsedException("You have already used your hero power this turn.");
		}
		
	}

	@Override
	public void onHeroDeath() {
		listener.onGameOver();
		
	}

	@Override
	public void damageOpponent(int amount) {
		this.getOpponent().setCurrentHP(this.getOpponent().getCurrentHP()-amount);
		
	}

	@Override
	public void endTurn() throws FullHandException, CloneNotSupportedException {
		Hero temp = this.getCurrentHero();
		this.currentHero = this.getOpponent();
		this.opponent = temp;
		this.getCurrentHero().setTotalManaCrystals(this.getCurrentHero().getTotalManaCrystals()+1);
		this.getCurrentHero().setCurrentManaCrystals(this.getCurrentHero().getTotalManaCrystals());
		this.getCurrentHero().setHeroPowerUsed(false);
		for(int i=0; i<this.getCurrentHero().getField().size();i++) {
			this.getCurrentHero().getField().get(i).setAttacked(false);
			if(this.getCurrentHero().getField().get(i).isSleeping())
				this.getCurrentHero().getField().get(i).setSleeping(false);
			
		}
		this.getCurrentHero().drawCard();
	}
	

	
	
	

}
