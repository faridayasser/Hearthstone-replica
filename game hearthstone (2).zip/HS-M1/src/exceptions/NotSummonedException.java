package exceptions;

@SuppressWarnings("serial")
public class NotSummonedException extends HearthstoneException {

	public NotSummonedException() {
		super();
	}

	public NotSummonedException(String message) {
		super(message);
		
	}

}
