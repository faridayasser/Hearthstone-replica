package model.cards.spells;

import java.util.ArrayList;

import model.cards.Rarity;
import model.cards.minions.Minion;

public class TwistingNether extends Spell implements AOESpell {

	public TwistingNether() {
		super("Twisting Nether", 8, Rarity.EPIC);

	}
	public void performAction(ArrayList<Minion> oppField, ArrayList<Minion> curField) {
		for(int i= 0;i<oppField.size() ;i++) {
			if(oppField.get(i).isDivine()) {
				oppField.get(i).setDivine(false);
			}
			oppField.get(i).setCurrentHP(0);
			i--;
		}
		for(int j= 0;j<curField.size();j++) {
			if(curField.get(j).isDivine()) {
				curField.get(j).setDivine(false);
			}
			curField.get(j).setCurrentHP(0);
			j--;
		}
	}

}
