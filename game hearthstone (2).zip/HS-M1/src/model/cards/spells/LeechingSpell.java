package model.cards.spells;
import model.cards.minions.*;
public interface LeechingSpell {
	public int performAction(Minion m);
}
