package model.cards.spells;

import model.heroes.*;
public interface HeroTargetSpell {
	public void performAction(Hero h);
}
