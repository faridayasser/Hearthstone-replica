package model.cards.spells;

import java.util.ArrayList;

import model.cards.Rarity;
import model.cards.minions.Minion;

public class MultiShot extends Spell implements AOESpell{

	public MultiShot() {
		super("Multi-Shot", 4,Rarity.BASIC);
		
	}
	public void performAction(ArrayList<Minion> oppField, ArrayList<Minion> curField) {
		int s = oppField.size();
		if (s==1) {
			if (oppField.get(0).isDivine()) {
				oppField.get(0).setDivine(false);
			}
			else {
				if (oppField.get(0).getCurrentHP()<=3)
					s--;
				oppField.get(0).setCurrentHP(oppField.get(0).getCurrentHP()-3);
			}
		}
		else if(s>1) {
			int index1 = (int)(Math.random()*(s));
			if (oppField.get(index1).isDivine()) {
				oppField.get(index1).setDivine(false);
			}
			else {
				if (oppField.get(index1).getCurrentHP()<=3)
					s--;
				oppField.get(index1).setCurrentHP(oppField.get(index1).getCurrentHP()-3);
			}
			int index2 = (int)(Math.random()*(s));
			while(index2 == index1) {
				index2 = (int)(Math.random()*(s));
			}
			if (oppField.get(index2).isDivine()) {
				oppField.get(index2).setDivine(false);
			}
			else {
				if (oppField.get(index2).getCurrentHP()<=3)
					s--;
				oppField.get(index2).setCurrentHP(oppField.get(index2).getCurrentHP()-3);
			}
		}
		else
			return;
		
	}

}
