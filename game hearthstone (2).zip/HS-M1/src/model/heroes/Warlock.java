package model.heroes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import exceptions.FullFieldException;
import exceptions.FullHandException;
import exceptions.HeroPowerAlreadyUsedException;
import exceptions.NotEnoughManaException;
import exceptions.NotYourTurnException;
import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.spells.CurseOfWeakness;
import model.cards.spells.SiphonSoul;
import model.cards.spells.TwistingNether;

public class Warlock extends Hero {

	public Warlock() throws IOException,CloneNotSupportedException {
		super("Gul'dan");
	}
	public void useHeroPower() throws NotEnoughManaException, HeroPowerAlreadyUsedException, NotYourTurnException, FullHandException, FullFieldException, CloneNotSupportedException{
		super.useHeroPower();
		boolean flag  = false;
		boolean flag2 = false;
		if (this.getField().size()>0) {
			for(int i= 0; i<this.getField().size();i++) {
				if (this.getField().get(i).getName().equals("Wilfred Fizzlebang"))
					flag = true;
			}
		}
		this.setCurrentHP(this.getCurrentHP()-2);
		if (this.getHand().size()==10) {
			throw new FullHandException("You can't draw another card, you already have 10 cards in hand.",this.getDeck().get(0) );
		}
		Card c = this.drawCard2();
		if (this.getField().size()>0) {
			for(int i= 0; i<this.getField().size();i++) {
				if (this.getField().get(i).getName().equals("Chromaggus"))
					flag2 = true;
			}
		}
		if(flag && c instanceof Minion && flag2) {
			c.setManaCost(0);
			if(this.getHand().size()<10) {
				 this.getHand().add(c.clone());
			}
		}
		else if(flag && c instanceof Minion) {
			c.setManaCost(0);
		}
		else if(flag2) {
			 if(this.getHand().size()<10) 
				 this.getHand().add(c.clone());
		}
		
		this.setHeroPowerUsed(true);
		
	
	}
	@Override
	public void buildDeck() throws IOException,CloneNotSupportedException {
		ArrayList<Minion> neutrals= getNeutralMinions(getAllNeutralMinions("neutral_minions.csv"),13);
		getDeck().addAll(neutrals);
		for(int i = 0 ; i < 2; i++)
		{
			getDeck().add(new CurseOfWeakness());
			getDeck().add(new SiphonSoul());
			getDeck().add(new TwistingNether());
		}
		Minion wilfred=new Minion("Wilfred Fizzlebang",6,Rarity.LEGENDARY,4,4,false,false,false);
		getDeck().add(wilfred);
		Collections.shuffle(getDeck());
		
		for(int i=0; i<getDeck().size();i++) {
			if(getDeck().get(i) instanceof Minion) {
				Minion m = (Minion) getDeck().get(i);
				m.setListener(this);
			}
			}

	}
	

}
