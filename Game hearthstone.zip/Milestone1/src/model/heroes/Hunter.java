package model.heroes;
import model.cards.*;
import java.util.ArrayList;
import java.util.Collections;

import model.cards.spells.*;
import model.cards.minions.*;

import java.io.IOException;

public class Hunter extends Hero{

	public Hunter() throws IOException{
		super("Rexxar");
		this.buildDeck();
		
		
	}

	@Override
	public void buildDeck() throws IOException {
		ArrayList<Minion> m = getAllNeutralMinions("neutral_minions.csv");
		//ArrayList<Card> d = new ArrayList<Card>();
		this.getDeck().addAll(getNeutralMinions(m,15));
		Spell k1 = new KillCommand();
		this.getDeck().add(k1);
		Spell k2 = new KillCommand();
		this.getDeck().add(k2);
		Spell m1 = new MultiShot();
		this.getDeck().add(m1);
		Spell m2 = new MultiShot();
		this.getDeck().add(m2);
		Minion s  = new Minion("King Krush",9, Rarity.LEGENDARY, 8,8,false,false,true);
		
		this.getDeck().add(s);
		Collections.shuffle(this.getDeck());
		
	}

	
	

}
