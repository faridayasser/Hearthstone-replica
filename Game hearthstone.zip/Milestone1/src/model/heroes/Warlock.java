package model.heroes;

import java.io.IOException;

import model.cards.*;
import model.cards.minions.*;
import model.cards.spells.*;
import java.util.ArrayList;
import java.util.Collections;


public class Warlock extends Hero {

	public Warlock()throws IOException{
		super("Gul'dan");
		this.buildDeck();
		
	}

	@Override
	public void buildDeck() throws IOException {
		ArrayList<Minion> m = getAllNeutralMinions("neutral_minions.csv");
		this.getDeck().addAll(getNeutralMinions(m,13));
		CurseOfWeakness c1 = new CurseOfWeakness();
		this.getDeck().add(c1);
		CurseOfWeakness c2 = new CurseOfWeakness();
		this.getDeck().add(c2);
		SiphonSoul s1 = new SiphonSoul();
		this.getDeck().add(s1);
		SiphonSoul s2 = new SiphonSoul();
		this.getDeck().add(s2);
		TwistingNether n1 = new TwistingNether();
		this.getDeck().add(n1);
		TwistingNether n2 = new TwistingNether();
		this.getDeck().add(n2);
		Minion s  = new Minion("Wilfred Fizzlebang",6, Rarity.LEGENDARY, 4,4,false,false,false);
		this.getDeck().add(s);
		Collections.shuffle(this.getDeck());
		
	}
	

}
