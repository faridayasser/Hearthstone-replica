package model.heroes;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import model.cards.spells.*;
import model.cards.*;
import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Icehowl;
import model.cards.minions.Minion;
public abstract class Hero{
	private String name;
	private int currentHP;
	private boolean heroPowerUsed;
	private int totalManaCrystals;
	private int currentManaCrystals;
	private ArrayList<Card> deck;
	private ArrayList<Minion> field;
	private ArrayList<Card> hand;
	private int fatigueDamage;
	

	public Hero(String name) throws IOException{
		this.name = name;
		this.currentHP = 30;
		this.heroPowerUsed = false;
		this.totalManaCrystals = 0;
		this.currentManaCrystals = totalManaCrystals ;
		this.deck = new ArrayList<Card>();
		this.field = new ArrayList<Minion>();
		this.hand = new ArrayList<Card>();
		this.fatigueDamage = 0;
		
		

	}
	
	public int getCurrentHP() {
		return currentHP;
	}
	public void setCurrentHP(int currentHP) {
		if (currentHP>30) {
			this.currentHP = 30;}
		else {
			this.currentHP = currentHP;}
	}
	
	public boolean isHeroPowerUsed() {
		return heroPowerUsed;
	}
	public void setHeroPowerUsed(boolean heroPowerUsed) {
		this.heroPowerUsed = heroPowerUsed;
	}
	public int getTotalManaCrystals() {
		return totalManaCrystals;
	}
	public void setTotalManaCrystals(int totalManaCrystals) {
		if(totalManaCrystals>10) {
		this.totalManaCrystals = 10;}
		else {
			this.totalManaCrystals = totalManaCrystals;
			}
		
		}
	public int getCurrentManaCrystals() {
		return currentManaCrystals;
	}
	public void setCurrentManaCrystals(int currentManaCrystals) {
		if(currentManaCrystals>10) {
		this.currentManaCrystals = 10;}
		else {
			this.currentManaCrystals = currentManaCrystals;
			}
	}
	public String getName() {
		return name;
	}
	public ArrayList<Card> getDeck() {
		return deck;
	}
	public ArrayList<Minion> getField() {
		return field;
	}
	public ArrayList<Card> getHand() {
		return hand;
	}
	public static ArrayList<String> readFile(String path) throws IOException{
		ArrayList<String> m = new ArrayList<>();
		String currentLine = "";
		FileReader fileReader= new FileReader(path);
		BufferedReader br = new BufferedReader(fileReader);
		while ((currentLine = br.readLine()) != null) {
			m.add(currentLine);
		 }
		br.close();
		return m;
		    }
	public final static ArrayList<Minion> getAllNeutralMinions(String filePath) throws IOException{
		ArrayList<Minion> a = new ArrayList<Minion>();
		ArrayList<String> b = readFile(filePath);
		int bs = b.size();
		Minion m = new Minion();
		for(int i = 0;i<bs;i++) {
			String c = b.get(i);
			String [] result= c.split(",");
			if (result[0].equalsIgnoreCase("Icehowl")){
				m = new Icehowl();
			}
			else {
				int n=Integer.parseInt(result[1]);
				int n1=Integer.parseInt(result[3]);
				int n2=Integer.parseInt(result[4]);
				boolean b4 = false;
				if (result[5].equals("FALSE"))
						b4 = false;
				else
					b4 = true;
				boolean b5 = false;
				if (result[6].equals("FALSE"))
					b5 = false;
				else
				b5 = true;
				boolean b6 = false;
				if (result[7].equals("FALSE"))
					b6 = false;
				else
					b6 = true;
				Rarity r = Rarity.BASIC;
				if(result[2].charAt(0) == 'b')
					r = Rarity.BASIC;
				else if(result[2].charAt(0) == 'r')
					r = Rarity.RARE;
				else if(result[2].charAt(0) == 'l')
					r = Rarity.LEGENDARY;
				else if(result[2].charAt(0) == 'c')
					r = Rarity.COMMON;
				else if(result[2].charAt(0) == 'e')
					r = Rarity.EPIC;
				
	
				m = new Minion(result[0],n,r,n1,n2,b4,b5,b6);
			}
			a.add(m);
			

		}
		
		
		return a;
	}
	
	public final static ArrayList<Minion> getNeutralMinions(ArrayList<Minion> minions,int count)throws IOException{
		ArrayList<Minion> m = new ArrayList<Minion>();
		for(int i = 0;i<count;i++) {
			Random r = new Random();
			Minion m1 = minions.get(r.nextInt(minions.size()));
			int o = Collections.frequency(m, m1);
			if (m1.getRarity()==(Rarity.LEGENDARY)){
				if(o<1) {
					m.add(m1);
					
			}
				else i--;
				}
			else {
				if(o<2) {
					m.add(m1);
					}
				else
					i--;
			}
			}
		
		return m;
		
		
	}
	public abstract void buildDeck() throws IOException;
	
		
	}

	
	
	
	
	

