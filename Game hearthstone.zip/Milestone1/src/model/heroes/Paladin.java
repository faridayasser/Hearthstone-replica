package model.heroes;
import model.cards.*;
import model.cards.minions.*;
import model.cards.spells.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Paladin extends Hero {

	public Paladin() throws IOException{
		super("Uther Lightbringer");
		this.buildDeck();
			}

	@Override
	public void buildDeck() throws IOException {
		ArrayList<Minion> m = getAllNeutralMinions("neutral_minions.csv");
		this.getDeck().addAll(getNeutralMinions(m,15));
		SealOfChampions s1 = new SealOfChampions();
		this.getDeck().add(s1);
		SealOfChampions s2 = new SealOfChampions();
		this.getDeck().add(s2);
		LevelUp l1 = new LevelUp();
		this.getDeck().add(l1);
		LevelUp l2 = new LevelUp();
		this.getDeck().add(l2);
		Minion s  = new Minion("Tirion Fordring",4, Rarity.LEGENDARY, 6,6,true,true,false);
		
		this.getDeck().add(s);
		Collections.shuffle(this.getDeck());

	
	}
	
	

}
