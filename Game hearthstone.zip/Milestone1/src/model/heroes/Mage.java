package model.heroes;
import model.cards.*;
import java.util.ArrayList;
import java.util.Collections;

import model.cards.spells.*;
import model.cards.minions.*;

import java.io.IOException;

public class Mage extends Hero {

	public Mage()throws IOException{
		super("Jaina Proudmoore");
		this.buildDeck();
		
		
		
	}
	
	@Override
	public void buildDeck() throws IOException {
		ArrayList<Minion> m = getAllNeutralMinions("neutral_minions.csv");
		//ArrayList<Card> d = new ArrayList<Card>();
		this.getDeck().addAll(getNeutralMinions(m,13));
		Polymorph p1 = new Polymorph();
		this.getDeck().add(p1);
		Polymorph p2 = new Polymorph();
		this.getDeck().add(p2);
		Flamestrike f1 = new Flamestrike();
		this.getDeck().add(f1);
		Flamestrike f2 = new Flamestrike();
		this.getDeck().add(f2);
		Pyroblast b1 = new Pyroblast();
		this.getDeck().add(b1);
		Pyroblast b2 = new Pyroblast();
		this.getDeck().add(b2);
		Minion s  = new Minion("Kalycgos",10, Rarity.LEGENDARY, 4,12,false,false,false);
		this.getDeck().add(s);
		Collections.shuffle(this.getDeck());

		
	}

	


}
