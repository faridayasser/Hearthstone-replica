package model.heroes;
import java.io.IOException;

import model.cards.*;
import model.cards.minions.*;
import model.cards.spells.*;
import java.util.ArrayList;
import java.util.Collections;

public class Priest extends Hero{

	public Priest()throws IOException{
		super("Anduin Wrynn");
		this.buildDeck();
	}

	@Override
	public void buildDeck() throws IOException {
		ArrayList<Minion> m = getAllNeutralMinions("neutral_minions.csv");
		
	
		this.getDeck().addAll(getNeutralMinions(m,13));
		DivineSpirit d1 = new DivineSpirit();
		this.getDeck().add(d1);
		DivineSpirit d2 = new DivineSpirit();
		this.getDeck().add(d2);
		HolyNova h1 = new HolyNova();
		this.getDeck().add(h1);
		HolyNova h2 = new HolyNova();
		this.getDeck().add(h2);
		ShadowWordDeath s1 = new ShadowWordDeath();
		this.getDeck().add(s1);
		ShadowWordDeath s2 = new ShadowWordDeath();
		this.getDeck().add(s2);
		Minion s  = new Minion("Prophet Velen",7, Rarity.LEGENDARY, 7,7,false,false,false);
		this.getDeck().add(s);
		Collections.shuffle(this.getDeck());
	}
	

}
