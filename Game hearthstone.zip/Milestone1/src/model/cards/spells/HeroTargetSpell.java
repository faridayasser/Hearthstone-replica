package model.cards.spells;

public interface HeroTargetSpell {

}
