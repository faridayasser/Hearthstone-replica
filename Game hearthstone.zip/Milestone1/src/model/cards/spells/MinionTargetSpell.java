package model.cards.spells;

public interface MinionTargetSpell {

}
