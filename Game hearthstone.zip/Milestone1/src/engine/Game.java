package engine;
import java.util.*;
import model.heroes.Hero;

public class Game {
	private Hero firstHero;
	private Hero secondHero;
	private Hero currentHero;
	private Hero opponent;
	
	public Game(Hero p1,Hero p2) {
		
		firstHero = p1;
		secondHero = p2;
		Hero[]h= new Hero[2];
		h[0] = p1;
		h[1] =p2;
		int index = (int) Math.round(Math.random());
		if (index == 1) {
			currentHero = p2;
			opponent = p1;
		}
		else {
			currentHero = p1;
			opponent = p2;
		}
	}

	public Hero getCurrentHero() {
		return currentHero;
	}

	public Hero getOpponent() {
		return opponent;
	}
	
	
	
	
	

}
