package exceptions;

public class HeroPowerAlreadyUsedException extends HearthstoneException {

	public HeroPowerAlreadyUsedException() {
		super();
}

	public HeroPowerAlreadyUsedException(String s) {
		super(s);
}

}
