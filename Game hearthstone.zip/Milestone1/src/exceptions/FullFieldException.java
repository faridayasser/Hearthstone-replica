package exceptions;

public class FullFieldException extends HearthstoneException {

	public FullFieldException() {
		super();
	
	}

	public FullFieldException(String s) {
		super(s);
	}

}
