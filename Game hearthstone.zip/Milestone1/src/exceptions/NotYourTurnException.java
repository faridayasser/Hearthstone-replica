package exceptions;

public class NotYourTurnException extends HearthstoneException {

	public NotYourTurnException() {
		super();
	}

	public NotYourTurnException(String s) {
		super(s);
}

}
