package exceptions;

public class NotEnoughManaException extends HearthstoneException {

	public NotEnoughManaException() {
		super();

	}

	public NotEnoughManaException(String s) {
		super(s);
	}

}
